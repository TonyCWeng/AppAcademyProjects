def range(num1, num2)
  return [] if num2 < num1
  return [num1] if num1 == num2
  arr = [num1]
  arr = arr + range(num1 + 1, num2)
end

def iterative_sum(arr)
  sum = 0
  arr.each {|num| sum += num}
  sum
end

def recursive_sum(arr)
  return arr[0] if arr.length == 1
  sum = arr.pop + recursive_sum(arr)
end

def exponent1(base, power)
  return 1 if power == 0
  base * exponent1(base, power - 1)
end

def exponent2(base, power)
  return 1 if power == 0
  if power.even?
    even_power = exponent2(base, power/2)
    even_power * even_power
  else
    odd_power = exponent2(base, (power-1)/2)
    base * (odd_power * odd_power)
  end
end

class Array
  def deep_dup
    result = []
    self.each do |element|
      if element.is_a? Array
        result << element.deep_dup
      else
        result << element
      end
    end

    result
  end
end

#example
# arr = ["dog", ["cat", "pig"]]
# arr2 = arr.deep_dup
# arr2[1][0] = "bird"
# p arr2
# p arr

def fib(n)
  if n == 1
    [0]
  elsif n == 2
    [0, 1]
  else
    holder = fib(n - 1)
    holder << (holder[-1] + holder[-2])
  end
end

def subsets(arr)

  return [[]] if arr.empty?

  prev_array = subsets(arr[0..-2])
  subset_array = prev_array.map do |el|
    el + [arr[-1]]
  end

  subset_array = subsets(arr[0..-2])

  prev_array.each do |element|
    subset_array << (element << arr[-1])
  end

  subset_array
end

# p subsets([1,2,3])

def perm(arr)
  perm_array = []

  return [arr] if arr.length == 1
  a = perm(arr[0..-2])
  a.each do |array|
    (array.length+1).times do |i|
      perm_array << array.dup.insert(i, arr[-1])
    end
  end
  perm_array
end

#p perm([1,2,3]).sort

# perm example
# a = [1,2,3]
# b = 8
# result = []
# num = a.count
#
#
# (a.length+1).times do |i|
#   result << a.dup.insert(i, b)
#
# end
#
# print result

def bsearch(arr, target)
  return nil if arr.empty?
  return arr.index(target) if arr[arr.length / 2] == target

  if target < arr[arr.length / 2]
    bsearch(arr[0...(arr.length / 2)], target)
  else
    pos = bsearch(arr[((arr.length / 2)+1)..-1], target)
    pos == nil ? nil : pos + ((arr.length/2)+1)
  end
end

def merge_sort(arr)
  final_array = []
  return [] if arr.empty?
  return arr if arr.length == 1
  half = arr.length/2
  first_half = arr[0..(half)]
  second_half = arr[((half) + 1)..-1]
  result = []
  result << first_half << second_half
  sorted_left = merge_sort(first_half)
  sorted_right = merge_sort(second_half)
    # result.each do |sub|
    #   final_array << merge_sort(sub)
    # end
    #
    #
    # print final_array

    merge(sorted_left, sorted_right)

end

merge_sort([38,27,43,3,9,82,10])

def merge(so)
end

def greedy_make_change(amount, coins)
  result = []
  return amount if amount % coins[0] == 0
  until amount < coins[0]
    result << coins[0]
    amount -= coins[0]
  end
  result += [greedy_make_change(amount, coins[1..-1])]
end

greedy_make_change(88, [25, 10, 5, 1]) #-> 25,25,25,10,1,1,1
