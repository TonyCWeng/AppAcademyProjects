require_relative 'piece'

class Bishop < Piece
  include SlidingPiece

  def initialize
    @potential_positions = []
  end

  def move_dirs
    POSSIBLE_DIRS[1]
  end

end
