require_relative 'piece'

class NullPiece < Piece

  def initialize
    @color = :place_holder
    @value = :nil
  end

  def test
    puts self
  end
end

n = NullPiece.new

n.test
