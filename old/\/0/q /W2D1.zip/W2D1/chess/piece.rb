require_relative 'board'
require_relative 'sliding_piece'
require_relative 'stepping_piece'

class Piece
  attr_reader :value, :moves, :current_pos

  def initialize(board)
    @value = "p"
    @possible_moves = []
    @current_pos = []
    @color = nil
    @board = board
  end

  def moves

  end
end
