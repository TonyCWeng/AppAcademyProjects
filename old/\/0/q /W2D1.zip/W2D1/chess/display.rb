require 'colorize'
require 'byebug'
require_relative 'board'
require_relative 'cursor'

class Display

  def initialize(board)
    @board = board
    @cursor = Cursor.new(board)
    @current_pos = @cursor.cursor_pos
  end

  def render(position)
    @board[position].value.green
  end

  def render_board
    mapped = Array.new(8){Array.new(8)}
    @board.grid.each.with_index do |row, i|
      row.each.with_index do |pos, j|
        if [i, j] == @current_pos
          mapped[i][j] = render(@current_pos)
        else
          mapped[i][j] = pos.value
        end
      end
    end
    mapped
  end

  def format_board
    board = render_board
    board.each do |row|
      puts row.join(" ")
    end
  end

  def loop_test
    # debugger
    pos =  @cursor.get_input
    @current_pos = @cursor.cursor_pos

    while pos.nil?
      pos =  @cursor.get_input
      @current_pos = @cursor.cursor_pos
      system 'clear'
      format_board
    end
  end
end

b = Board.new
b.populate

d = Display.new(b)
d.loop_test
