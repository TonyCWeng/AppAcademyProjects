require_relative 'piece'
require_relative 'sliding_piece'

class Rook < Piece
  include SlidingPiece

  def move_diff
    [

    ]
  end
end


r = Rook.new

p r.pos_vert([4,4])
p r.pos_horz([4,4])
