class HumanPlayer
  attr_reader :name

  def initialize(name = "player1")
    @name = name
  end
end
