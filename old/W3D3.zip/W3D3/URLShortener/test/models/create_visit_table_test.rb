require 'test_helper'

class CreateVisitTableTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
